<?php
require_once 'db/dbcon.php';

$error = array();
mysqli_report(MYSQLI_REPORT_OFF);

if (isset($_POST['submit'])){
    $role = $_POST['role'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    date_default_timezone_set ("Asia/Dhaka");
    $reg_time = date("Y-m-d H:i:s");

    $hashed_password = password_hash ($password, PASSWORD_DEFAULT);

    // For different table
    // if ($role == 'teacher'){
    //     $table = 'teachers_registration';
    // } elseif ($role == 'staff'){
    //     $table = 'staff_registration';
    // } elseif ($role == 'editor'){
    //     $table = 'editors_registration';
    // } elseif ($role == 'admin'){
    //     $table = 'admin_registration';
    // }

    if (empty($role)){
        $error['role'] = "required !";
    }
    if (empty($username)){
        $error['username'] = "required !";
    }
    if (empty($email)){
        $error['email'] = "required !";
    }
    if (empty($password)){
        $error['password'] = "required !";
    }
    if (strlen($password)>=8 && empty($confirm_password)){
        $error['confirm_password'] = "required !";
    }
    if (!empty($password) && strlen($password) < 8){
        $error['pass_len'] = "password must have 8 charecters long.";
    }
    if (strlen($password)>=8 && !empty($confirm_password) && $password !== $confirm_password){
        $error['pass_mismatch'] = "passwords do not match!";
    }

    if (empty($error)){
        // $username_select = mysqli_query($dbcon, "SELECT * FROM `user_role_reg` WHERE username = '$username'");
        // $email_select = mysqli_query($dbcon, "SELECT * FROM `user_role_reg` WHERE email = '$email'");

        // if (mysqli_num_rows($username_select) > 0){
        //     $error['username_taken'] = "This email is already registered !";
        // } elseif (mysqli_num_rows($email_select) >0){
        //     $error['email_taken'] = "This email is already registered !";
        // }else{
            $insert_query = mysqli_query ($dbcon, "INSERT INTO `user_role_reg`(`role`, `username`, `email`, `password`, `reg_time`) VALUES ('$role','$username','$email','$hashed_password','$reg_time')");

        if ($insert_query){
            echo "<script>
            window.location.href = 'registration_submit_message.html';
            </script>";
            exit();
        }
        else{
            if (mysqli_errno($dbcon) == 1062) {
            $error['duplicate'] =
            "This username or email is already registered for this role.";
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/register.css">
</head>
<body>
<div class="register_container">
    <form action="" method="POST" class="register_form">
        <h1>Register</h1>

        <label for="">User Role</label>
        <select name="role" value="<?php if(isset($role)){echo $role;} ?>">
            <option value="" style="color: gray;">Select</option>
            <option value="teacher" <?php if(isset($role) && $role == 'teacher'){echo 'selected';} ?>>Teacher</option>
            <option value="staff" <?php if(isset($role) && $role == 'staff'){ echo 'selected';} ?>>Staff</option>
            <option value="editor" <?php if(isset($role) && $role == 'editor'){echo 'selected';} ?> >Editor</option>
            <option value="admin" <?php if(isset($role) && $role == 'admin'){ echo 'selected';} ?>>Admin</option>
        </select>
        <span for="" style="display: block; text-align: right; color: red; font-size: 17px;">
            <?php
            if (isset($error['role'])){
                echo $error['role'];
            }
            ?>
        </span>

            <input name="username" type="text" placeholder="username" value="<?php if(isset($username)){echo $username;} ?>">
            <span for="" style="display: block; text-align: right; color: red; font-size: 17px;">
                <?php
                if (isset($error['username'])){
                    echo $error['username'];
                }
                if (isset($error['username_taken'])){
                    echo $error['username_taken'];
                }
                if (isset($error['duplicate'])){
                    echo $error['duplicate'];
                }
                ?>
            </span>

            <input name="email" type="text" placeholder="Enter your email" value="<?php if(isset($email)){echo $email;} ?>">
            <span for="" style="display: block; text-align: right; color: red; font-size: 17px;">
                <?php
                if (isset($error['email'])){
                    echo $error['email'];
                }
                if (isset($error['email_taken'])){
                    echo $error['email_taken'];
                }
                if (isset($error['duplicate'])){
                    echo $error['duplicate'];
                }
                ?>
            </span>

            <input name="password" type="password" placeholder="New password" value="<?php if(isset($password)){echo $password;} ?>">
            <span for="" style="display: block; text-align: right; color: red; font-size: 17px;">
                <?php
                if (isset($error['password'])){
                    echo $error['password'];
                }
                if (isset($error['pass_len'])){
                    echo $error['pass_len'];
                }
                ?>
            </span>

            <input name="confirm_password" type="password" placeholder="Confirm new password" value="<?php if(isset($confirm_password)){echo $confirm_password;} ?>">
            <span for="" style="display: block; text-align: right; color: red; font-size: 17px;">
                <?php
                if (isset($error['confirm_password'])){
                    echo $error['confirm_password'];
                }
                if (isset($error['pass_mismatch'])){
                    echo $error['pass_mismatch'];
                }
                ?>
            </span>
        
            <input name="submit" type="submit" value="Submit" class="button">

            <p>Already have an account? <a href="login.php">Login</a></p>
    </form>
</div> 
</body>
</html>