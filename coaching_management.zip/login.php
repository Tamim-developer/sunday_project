<?php
require_once 'db/dbcon.php';

$error = array ();

if (isset($_POST['login'])){
    $role = $_POST['role'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    date_default_timezone_set ("Asia/Dhaka");
    $login_time = date("Y-m-d H:i:s");


    if (empty($role)){
        $error['role'] = "required !";
    }
    if (empty($username)){
        $error['username'] = "required !";
    }
    if (empty($password)){
        $error['password'] = "required !";
    }

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
    <!-- Google font link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Edu+NSW+ACT+Cursive:wght@400..700&family=Roboto:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet"> 
</head>
<body>
    <form method="POST" action="" class="login_form">
        <h1>Login</h1>

        <label for="">User Role</label>
        <select name="role">
            <option value="" style="color: gray;">Select</option>
            <option value="teacher" <?php if(isset($role) && $role == 'teacher'){echo "selected";} ?>>Teacher</option>
            <option value="staff" <?php if(isset($role) && $role == 'staff'){echo "selected";} ?>>Staff</option>
            <option value="editor" <?php if(isset($role) && $role == 'editor'){echo "selected";} ?>>Editor</option>
            <option value="admin" <?php if(isset($role) && $role == 'admin'){echo "selected";} ?>>Admin</option>
        </select>
        <span for="" style="display: block; text-align: right; color: red; font-size: 17px;">
            <?php
            if (isset($error['role'])){
                echo $error['role'];
            }
            ?>
        </span>


        <label for="">Username</label>
        <input name="username" type="text" placeholder="username">
        <span for="" style="display: block; text-align: right; color: red; font-size: 17px;">
            <?php
            if (isset($error['username'])){
                echo $error['username'];
            }
            ?>
        </span>


        <label for="">Password</label>
        <input name="password" type="password" placeholder="Password">
        <span for="" style="display: block; text-align: right; color: red; font-size: 17px;">
            <?php
            if (isset($error['password'])){
                echo $error['password'];
            }
            ?>
        </span>


        <a href=""><button name="login" style="color: white;">Login</button></a>

        <p>Forget password ? <a href="">Click Here</a></p>
        <p>Don't have an account ? <a href="register.php">Click Here</a></p>
    </form>
</body>
</html>